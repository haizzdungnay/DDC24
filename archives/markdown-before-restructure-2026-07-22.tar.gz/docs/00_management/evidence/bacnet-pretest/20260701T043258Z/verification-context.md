# BACnet ADR-011/012 Local Verification Context

- Date: 2026-07-01 (UTC run ID `20260701T043258Z`)
- Source: local `main` at `9b2657b` plus the uncommitted integration-review fixes in this worktree.
- Server: clean `MKDDC_ENABLE_BACNET=ON` build of `mkddc-iobus`, bacnet-stack 1.3.8, device instance `4194002`.
- Transport: server bound to host `docker0`; bacnet-stack client tools ran as a separate Docker bridge node to preserve the normal BACnet/IP UDP/47808 topology.
- IOP: `socat` PTY plus `fake_mcu`; AO1 config was `CW VALVE`, `percent`, `0..100`, physical mode `0-10V`.

## Result

- BTL smoke harness: 14 PASS / 0 FAIL; Who-Is/I-Am 58 ms.
- ReadProperty confirmed AI1 Units=`volts`, Reliability=`no-fault-detected`.
- ReadProperty confirmed AO1 Object_Name=`CW VALVE`, Units=`percent`, Min_Pres_Value=`0`, Max_Pres_Value=`100`.
- WriteProperty AO1 Present_Value=`50` at priority 8 acknowledged and read back `50`; relinquish acknowledged.
- Runtime bridge log confirmed AO1 engineering value `50%` produced DAC raw `32768` (5 V equivalent), and relinquish returned raw to `0`.

## Scope limit

This is a real UDP/47808 local smoke with a simulated IOP, not Orange Pi hardware evidence. Repeat the same harness on the board/LAN before closing the board and BTL-lab gates.
