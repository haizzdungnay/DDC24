# Advanced Stack Test — Wed Jun 17 06:47:37 AM CEST 2026
## Kết quả
| Kết quả | Số test |
|---------|---------|
| PASS    | 19   |
| FAIL    | 0   |
| SKIP    | 3   |

## Test groups
- Group A (safe-state): TC-ADV-A01..A03
- Group B (SIGHUP reload): TC-ADV-B01..B02
- Group C (priority resolver): TC-ADV-C01..C05
- Group D (ext cache datagram): TC-ADV-D01..D02
- Group E (fault injection): TC-ADV-E01..E02
