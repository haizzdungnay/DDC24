# Soak Test Report - SOM No-MCU Simulation Stack
Date: 2026-06-19 06:07:21
Duration: 30s
Command Write Period: 5s
Fault Injection Period: 15s
Metrics Sample Period: 5s

## Summary Statistics

| Metric | `mkddc-iobus` | `mkddc-core` |
| --- | --- | --- |
| Average CPU Usage | 0.55% | 0.00% |
| Max CPU Usage | 0.97% | 0.00% |
| Average RSS Memory | 6396.0 KB | 6580.0 KB |
| Max RSS Memory | 6396.0 KB | 6580.0 KB |
| Memory Growth (Leak metric) | 0.0 KB | 0.0 KB |

## Robustness & Fault Tolerance

- **Command Send Success Rate**: 4/4 (100.0%)
- **Fault Injections (MCU Kill)**: 2 times
- **Fault Recoveries (MCU Revive & Connect)**: 1 times
- **Total Core Scan Overruns**: 0

## Final Verdict
> [!TIP]
> **PASSED** - All processes remained stable, memory growth was within limits, and fault recovery succeeded reliably.
